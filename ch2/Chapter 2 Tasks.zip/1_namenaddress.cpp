#include <iostream>

int main(){
    std::cout << "Hello!" << std::endl
              << "My name is Andrew and I live in Novosibirsk, Russia"
              << std::endl;
    return 0;
}
